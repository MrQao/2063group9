package projects;

public class projectnumber {
	private String projectnumber;
	
	projectnumber(){}
	
	public projectnumber(String projectN) {
		this.projectnumber = projectN;
	}
}
